import { create } from 'zustand'
import { Book, User, AppSettings } from '@prisma/client'

interface State {
  books: Book[]
  users: User[]
  appSettings: AppSettings | null
  setBooks: (books: Book[]) => void
  setUsers: (users: User[]) => void
  setAppSettings: (settings: AppSettings) => void
}

export const useStore = create<State>((set) => ({
  books: [],
  users: [],
  appSettings: null,
  setBooks: (books) => set({ books }),
  setUsers: (users) => set({ users }),
  setAppSettings: (settings) => set({ appSettings: settings }),
}))

