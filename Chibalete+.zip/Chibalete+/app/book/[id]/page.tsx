import { Metadata } from "next"
import { BookDetail } from "@/components/book-detail"

export const metadata: Metadata = {
  title: "Book Detail | Chibalete+",
  description: "Read and explore book content",
}

export default function BookDetailPage({ params }: { params: { id: string } }) {
  return <BookDetail id={params.id} />
}

