import { Metadata } from "next"
import { BookLibrary } from "@/components/book-library"

export const metadata: Metadata = {
  title: "Book Library | Chibalete+",
  description: "Browse and read books in your digital library",
}

export default function LibraryPage() {
  return <BookLibrary />
}

