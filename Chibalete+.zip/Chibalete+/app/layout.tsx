import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import ErrorBoundary from "@/components/error-boundary"
import { ErrorFallback } from "@/components/error-fallback"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Chibalete+",
  description: "A comprehensive digital reading experience",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          <ErrorBoundary fallback={<ErrorFallback error={new Error("Something went wrong")} resetErrorBoundary={() => window.location.reload()} />}>
            {children}
          </ErrorBoundary>
        </ThemeProvider>
      </body>
    </html>
  )
}

