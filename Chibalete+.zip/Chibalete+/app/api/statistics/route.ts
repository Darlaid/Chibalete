import { NextResponse } from "next/server"
import prisma from "@/lib/prisma"
import { getServerSession } from "next-auth/next"
import { authOptions } from "../auth/[...nextauth]/route"

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session || session.user.role !== "ADMIN") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const totalUsers = await prisma.user.count()
  const totalBooks = await prisma.book.count()
  
  // These would typically be more complex queries based on your specific requirements
  const activeReaders = Math.floor(totalUsers * 0.7) // Placeholder: 70% of total users
  const avgReadingTime = Math.floor(Math.random() * 60) + 30 // Placeholder: Random number between 30-90

  const monthlyActiveUsers = [
    { name: "Jan", total: Math.floor(Math.random() * 1000) },
    { name: "Feb", total: Math.floor(Math.random() * 1000) },
    { name: "Mar", total: Math.floor(Math.random() * 1000) },
    { name: "Apr", total: Math.floor(Math.random() * 1000) },
    { name: "May", total: Math.floor(Math.random() * 1000) },
    { name: "Jun", total: Math.floor(Math.random() * 1000) },
    { name: "Jul", total: Math.floor(Math.random() * 1000) },
    { name: "Aug", total: Math.floor(Math.random() * 1000) },
    { name: "Sep", total: Math.floor(Math.random() * 1000) },
    { name: "Oct", total: Math.floor(Math.random() * 1000) },
    { name: "Nov", total: Math.floor(Math.random() * 1000) },
    { name: "Dec", total: Math.floor(Math.random() * 1000) },
  ]

  return NextResponse.json({
    totalUsers,
    activeReaders,
    totalBooks,
    avgReadingTime,
    monthlyActiveUsers,
  })
}

