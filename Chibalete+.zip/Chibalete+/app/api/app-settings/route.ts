import { NextResponse } from "next/server"
import prisma from "@/lib/prisma"
import { getServerSession } from "next-auth/next"
import { authOptions } from "../auth/[...nextauth]/route"

export async function GET() {
  const appSettings = await prisma.appSettings.findFirst()
  return NextResponse.json(appSettings)
}

export async function PUT(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session || session.user.role !== "ADMIN") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const formData = await req.formData()
  const theme = formData.get("theme") as string
  const primaryColor = formData.get("primaryColor") as string
  const font = formData.get("font") as string
  const backgroundImage = formData.get("backgroundImage") as File | null

  let backgroundImageUrl = null
  if (backgroundImage) {
    // Here you would typically upload the file to a storage service
    // and get back a URL. For this example, we'll just use a placeholder.
    backgroundImageUrl = "/uploads/" + backgroundImage.name
  }

  const updatedSettings = await prisma.appSettings.upsert({
    where: { id: "1" }, // Assuming there's only one settings record
    update: {
      theme,
      primaryColor,
      font,
      backgroundImage: backgroundImageUrl,
    },
    create: {
      theme,
      primaryColor,
      font,
      backgroundImage: backgroundImageUrl,
    },
  })

  return NextResponse.json(updatedSettings)
}

