import { NextResponse } from "next/server"
import prisma from "@/lib/prisma"
import { getServerSession } from "next-auth/next"
import { authOptions } from "../auth/[...nextauth]/route"

export async function POST(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const { bookId, page } = await req.json()
  const bookmark = await prisma.bookmark.create({
    data: {
      userId: session.user.id,
      bookId,
      page,
    },
  })
  return NextResponse.json(bookmark)
}

export async function GET(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const bookmarks = await prisma.bookmark.findMany({
    where: { userId: session.user.id },
    include: { book: true },
  })
  return NextResponse.json(bookmarks)
}

