import { Metadata } from "next"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { AdminLoginForm } from "@/components/admin-login-form"

export const metadata: Metadata = {
  title: "Admin Login | Chibalete+",
  description: "Login to the Chibalete+ admin panel",
}

export default function AdminLoginPage() {
  return (
    <div className="flex h-screen w-full items-center justify-center bg-gray-100">
      <div className="w-full max-w-md space-y-8 rounded-xl bg-white p-8 shadow-md">
        <div className="text-center">
          <h1 className="text-3xl font-bold">Admin Login</h1>
          <p className="text-gray-600">Sign in to access the admin dashboard</p>
        </div>
        <AdminLoginForm />
        <div className="text-center">
          <Link className="text-sm text-gray-600 hover:underline" href="/">
            Back to user login
          </Link>
        </div>
      </div>
    </div>
  )
}

