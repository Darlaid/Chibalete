import { Metadata } from "next"
import { AdminDashboard } from "@/components/admin-dashboard"

export const metadata: Metadata = {
  title: "Admin Dashboard | Chibalete+",
  description: "Manage content, users, and app personalization",
}

export default function AdminDashboardPage() {
  return <AdminDashboard />
}

