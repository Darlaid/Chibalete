import { Metadata } from "next"
import Image from "next/image"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { LoginForm } from "@/components/login-form"

export const metadata: Metadata = {
  title: "Login | Chibalete+",
  description: "Login to your Chibalete+ account",
}

export default function LoginPage() {
  return (
    <div className="flex h-screen w-full items-center justify-center bg-cover bg-center" style={{ backgroundImage: "url('/placeholder.svg')" }}>
      <div className="w-full max-w-md space-y-8 rounded-xl bg-white/80 p-8 backdrop-blur-sm">
        <div className="flex flex-col items-center space-y-2 text-center">
          <Image
            src="/placeholder.svg"
            alt="Chibalete+ Logo"
            width={100}
            height={100}
            className="rounded-full"
          />
          <h1 className="text-3xl font-bold">Welcome to Chibalete+</h1>
          <p className="text-gray-600">Sign in to access your digital library</p>
        </div>
        <LoginForm />
        <div className="text-center">
          <Link className="text-sm text-gray-600 hover:underline" href="/forgot-password">
            Forgot your password?
          </Link>
        </div>
      </div>
      <Link href="/admin/login" className="absolute bottom-4 left-4 text-sm text-gray-600 hover:underline">
        Admin Access
      </Link>
    </div>
  )
}

