import { render, screen } from '@testing-library/react'
import { BookLibrary } from '@/components/book-library'

jest.mock('@/lib/store', () => ({
  useStore: () => ({
    books: [
      { id: '1', title: 'Test Book 1', author: 'Author 1', cover: '/placeholder.svg' },
      { id: '2', title: 'Test Book 2', author: 'Author 2', cover: '/placeholder.svg' },
    ],
  }),
}))

describe('BookLibrary', () => {
  it('renders the book library with books', () => {
    render(<BookLibrary />)
    
    expect(screen.getByText('Your Digital Library')).toBeInTheDocument()
    expect(screen.getByText('Test Book 1')).toBeInTheDocument()
    expect(screen.getByText('Test Book 2')).toBeInTheDocument()
    expect(screen.getByText('Author 1')).toBeInTheDocument()
    expect(screen.getByText('Author 2')).toBeInTheDocument()
  })
})

