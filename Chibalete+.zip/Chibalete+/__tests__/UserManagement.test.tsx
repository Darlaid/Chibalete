import { render, screen, fireEvent, waitFor } from '@testing-library/react'
import { UserManagement } from '@/components/user-management'
import { useStore } from '@/lib/store'

jest.mock('@/lib/store', () => ({
  useStore: jest.fn(),
}))

const mockFetch = jest.fn()
global.fetch = mockFetch

describe('UserManagement', () => {
  beforeEach(() => {
    (useStore as jest.Mock).mockReturnValue({
      users: [],
      setUsers: jest.fn(),
    })
    mockFetch.mockClear()
  })

  it('renders the user management form', () => {
    render(<UserManagement />)
    expect(screen.getByText('User Management')).toBeInTheDocument()
    expect(screen.getByLabelText('Name')).toBeInTheDocument()
    expect(screen.getByLabelText('Email')).toBeInTheDocument()
    expect(screen.getByLabelText('Password')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Add New User' })).toBeInTheDocument()
  })

  it('adds a new user when form is submitted', async () => {
    mockFetch.mockResolvedValueOnce({
      ok: true,
      json: () => Promise.resolve({ id: '1', name: 'John Doe', email: 'john@example.com', role: 'USER' }),
    })

    render(<UserManagement />)

    fireEvent.change(screen.getByLabelText('Name'), { target: { value: 'John Doe' } })
    fireEvent.change(screen.getByLabelText('Email'), { target: { value: 'john@example.com' } })
    fireEvent.change(screen.getByLabelText('Password'), { target: { value: 'password123' } })
    fireEvent.click(screen.getByRole('button', { name: 'Add New User' }))

    await waitFor(() => {
      expect(mockFetch).toHaveBeenCalledWith('/api/users', expect.any(Object))
    })
  })
})

