import { NextRequest } from 'next/server'
import { GET, POST } from '@/app/api/users/route'
import prisma from '@/lib/prisma'
import { getServerSession } from 'next-auth/next'

jest.mock('@/lib/prisma', () => ({
  user: {
    findMany: jest.fn(),
    create: jest.fn(),
  },
}))

jest.mock('next-auth/next', () => ({
  getServerSession: jest.fn(),
}))

describe('Users API', () => {
  beforeEach(() => {
    jest.clearAllMocks()
  })

  describe('GET /api/users', () => {
    it('returns users for admin', async () => {
      (getServerSession as jest.Mock).mockResolvedValue({ user: { role: 'ADMIN' } })
      ;(prisma.user.findMany as jest.Mock).mockResolvedValue([
        { id: '1', name: 'John Doe', email: 'john@example.com', role: 'USER' },
      ])

      const response = await GET()
      const data = await response.json()

      expect(response.status).toBe(200)
      expect(data).toEqual([{ id: '1', name: 'John Doe', email: 'john@example.com', role: 'USER' }])
    })

    it('returns unauthorized for non-admin users', async () => {
      (getServerSession as jest.Mock).mockResolvedValue({ user: { role: 'USER' } })

      const response = await GET()
      const data = await response.json()

      expect(response.status).toBe(401)
      expect(data).toEqual({ error: 'Unauthorized' })
    })
  })

  describe('POST /api/users', () => {
    it('creates a new user for admin', async () => {
      (getServerSession as jest.Mock).mockResolvedValue({ user: { role: 'ADMIN' } })
      ;(prisma.user.create as jest.Mock).mockResolvedValue({
        id: '1',
        name: 'John Doe',
        email: 'john@example.com',
        role: 'USER',
      })

      const request = new NextRequest('http://localhost:3000/api/users', {
        method: 'POST',
        body: JSON.stringify({ name: 'John Doe', email: 'john@example.com', password: 'password123' }),
      })

      const response = await POST(request)
      const data = await response.json()

      expect(response.status).toBe(200)
      expect(data).toEqual({ id: '1', name: 'John Doe', email: 'john@example.com', role: 'USER' })
    })

    it('returns unauthorized for non-admin users', async () => {
      (getServerSession as jest.Mock).mockResolvedValue({ user: { role: 'USER' } })

      const request = new NextRequest('http://localhost:3000/api/users', {
        method: 'POST',
        body: JSON.stringify({ name: 'John Doe', email: 'john@example.com', password: 'password123' }),
      })

      const response = await POST(request)
      const data = await response.json()

      expect(response.status).toBe(401)
      expect(data).toEqual({ error: 'Unauthorized' })
    })
  })
})

