"use client"

import { useState, useEffect } from "react"
import { useStore } from "@/lib/store"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Book } from "@prisma/client"

export function BookManagement() {
  const { books, setBooks } = useStore()
  const [title, setTitle] = useState("")
  const [author, setAuthor] = useState("")
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetchBooks()
  }, [])

  const fetchBooks = async () => {
    try {
      setLoading(true)
      const response = await fetch("/api/books")
      if (!response.ok) throw new Error("Failed to fetch books")
      const data = await response.json()
      setBooks(data)
    } catch (err) {
      setError("Failed to load books")
    } finally {
      setLoading(false)
    }
  }

  const addBook = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch("/api/books", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, author }),
      })
      if (!response.ok) throw new Error("Failed to add book")
      const newBook = await response.json()
      setBooks([...books, newBook])
      setTitle("")
      setAuthor("")
    } catch (err) {
      setError("Failed to add book")
    }
  }

  const deleteBook = async (id: string) => {
    try {
      const response = await fetch(`/api/books/${id}`, { method: "DELETE" })
      if (!response.ok) throw new Error("Failed to delete book")
      setBooks(books.filter((book) => book.id !== id))
    } catch (err) {
      setError("Failed to delete book")
    }
  }

  if (loading) return <div>Loading...</div>
  if (error) return <div>Error: {error}</div>

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Book Management</h2>
        <p className="text-gray-600">Add, edit, or delete books in your library</p>
      </div>
      <form onSubmit={addBook} className="space-y-4">
        <div className="grid gap-4 md:grid-cols-2">
          <div>
            <Label htmlFor="title">Book Title</Label>
            <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Enter book title" required />
          </div>
          <div>
            <Label htmlFor="author">Author</Label>
            <Input id="author" value={author} onChange={(e) => setAuthor(e.target.value)} placeholder="Enter author name" required />
          </div>
        </div>
        <Button type="submit">Add New Book</Button>
      </form>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Title</TableHead>
            <TableHead>Author</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {books.map((book) => (
            <TableRow key={book.id}>
              <TableCell>{book.title}</TableCell>
              <TableCell>{book.author}</TableCell>
              <TableCell>
                <Button variant="outline" size="sm" className="mr-2">
                  Edit
                </Button>
                <Button variant="destructive" size="sm" onClick={() => deleteBook(book.id)}>
                  Delete
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

