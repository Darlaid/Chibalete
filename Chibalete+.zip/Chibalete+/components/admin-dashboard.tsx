"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BookManagement } from "@/components/book-management"
import { UserManagement } from "@/components/user-management"
import { AppCustomization } from "@/components/app-customization"
import { Statistics } from "@/components/statistics"

export function AdminDashboard() {
  const [activeTab, setActiveTab] = useState("books")

  return (
    <div className="container mx-auto p-6">
      <h1 className="mb-6 text-3xl font-bold">Admin Dashboard</h1>
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="books">Books</TabsTrigger>
          <TabsTrigger value="users">Users</TabsTrigger>
          <TabsTrigger value="customization">Customization</TabsTrigger>
          <TabsTrigger value="statistics">Statistics</TabsTrigger>
        </TabsList>
        <TabsContent value="books">
          <BookManagement />
        </TabsContent>
        <TabsContent value="users">
          <UserManagement />
        </TabsContent>
        <TabsContent value="customization">
          <AppCustomization />
        </TabsContent>
        <TabsContent value="statistics">
          <Statistics />
        </TabsContent>
      </Tabs>
      <div className="mt-6 text-center">
        <Link href="/">
          <Button variant="outline">Logout</Button>
        </Link>
      </div>
    </div>
  )
}

