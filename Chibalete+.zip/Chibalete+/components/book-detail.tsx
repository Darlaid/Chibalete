// ... (previous imports)
import { useSession } from "next-auth/react"

export function BookDetail({ id }: { id: string }) {
  // ... (previous state)
  const { data: session } = useSession()
  const [bookmark, setBookmark] = useState<number | null>(null)

  useEffect(() => {
    fetchBook()
    if (session) {
      fetchBookmark()
    }
  }, [id, session])

  // ... (previous fetchBook function)

  const fetchBookmark = async () => {
    try {
      const response = await fetch(`/api/bookmarks?bookId=${id}`)
      if (!response.ok) throw new Error("Failed to fetch bookmark")
      const data = await response.json()
      if (data.length > 0) {
        setBookmark(data[0].page)
        setPageNumber(data[0].page)
      }
    } catch (err) {
      console.error("Failed to load bookmark", err)
    }
  }

  const addBookmark = async () => {
    try {
      const response = await fetch("/api/bookmarks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ bookId: id, page: pageNumber }),
      })
      if (!response.ok) throw new Error("Failed to add bookmark")
      const data = await response.json()
      setBookmark(data.page)
    } catch (err) {
      console.error("Failed to add bookmark", err)
    }
  }

  // ... (rest of the component)

  return (
    // ... (previous JSX)
    <CardFooter>
      <Button onClick={addBookmark}>
        {bookmark ? `Update Bookmark (Current: Page ${bookmark})` : "Add Bookmark"}
      </Button>
    </CardFooter>
    // ... (rest of the JSX)
  )
}

