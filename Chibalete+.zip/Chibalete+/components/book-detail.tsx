"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function BookDetail({ id }: { id: string }) {
  const [fontSize, setFontSize] = useState("medium")
  const [background, setBackground] = useState("white")

  // Mock book data
  const book = {
    title: "Sample Book Title",
    author: "John Doe",
    description: "This is a sample book description. It would typically contain a brief overview of the book's content.",
    content: "This is the beginning of the book's content. In a real application, this would be much longer and paginated.",
  }

  return (
    <div className="container mx-auto p-6">
      <Link href="/library">
        <Button variant="outline" className="mb-4">
          Back to Library
        </Button>
      </Link>
      <Card>
        <CardHeader>
          <CardTitle>{book.title}</CardTitle>
          <CardDescription>{book.author}</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="mb-4">{book.description}</p>
          <Tabs defaultValue="text">
            <TabsList>
              <TabsTrigger value="text">Text</TabsTrigger>
              <TabsTrigger value="pdf">PDF</TabsTrigger>
              <TabsTrigger value="additional">Additional Materials</TabsTrigger>
            </TabsList>
            <TabsContent value="text">
              <div className="mb-4 space-x-2">
                <Button onClick={() => setFontSize("small")} variant={fontSize === "small" ? "default" : "outline"}>
                  Small
                </Button>
                <Button onClick={() => setFontSize("medium")} variant={fontSize === "medium" ? "default" : "outline"}>
                  Medium
                </Button>
                <Button onClick={() => setBackground("white")} variant={background === "white" ? "default" : "outline"}>
                  White
                </Button>
                <Button onClick={() => setBackground("cream")} variant={background === "cream" ? "default" : "outline"}>
                  Cream
                </Button>
                <Button onClick={() => setBackground("black")} variant={background === "black" ? "default" : "outline"}>
                  Black
                </Button>
              </div>
              <div
                className={`p-4 ${fontSize === "small" ? "text-sm" : "text-base"} ${
                  background === "white" ? "bg-white text-black" : background === "cream" ? "bg-amber-50 text-black" : "bg-black text-white"
                }`}
              >
                {book.content}
              </div>
            </TabsContent>
            <TabsContent value="pdf">PDF viewer would be implemented here</TabsContent>
            <TabsContent value="additional">Additional materials (videos, PDFs) would be listed here</TabsContent>
          </Tabs>
        </CardContent>
        <CardFooter>
          <Button>Add Bookmark</Button>
        </CardFooter>
      </Card>
    </div>
  )
}

