import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export function AppCustomization() {
  return (
    <div className="space-y-6">
      <div>
<h2 className="text-2xl font-bold">App Customization</h2>
        <p className="text-gray-600">Customize the look and feel of the Chibalete+ app</p>
      </div>
      <div className="space-y-4">
        <div>
          <Label htmlFor="theme">App Theme</Label>
          <Select>
            <SelectTrigger id="theme">
              <SelectValue placeholder="Select a theme" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="light">Light</SelectItem>
              <SelectItem value="dark">Dark</SelectItem>
              <SelectItem value="system">System</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="primary-color">Primary Color</Label>
          <Input id="primary-color" type="color" className="h-10 w-20" />
        </div>
        <div>
          <Label htmlFor="font">Font</Label>
          <Select>
            <SelectTrigger id="font">
              <SelectValue placeholder="Select a font" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="sans">Sans-serif</SelectItem>
              <SelectItem value="serif">Serif</SelectItem>
              <SelectItem value="mono">Monospace</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="background-image">Login Background Image</Label>
          <Input id="background-image" type="file" accept="image/*" />
        </div>
      </div>
      <Button>Save Customization</Button>
    </div>
  )
}

