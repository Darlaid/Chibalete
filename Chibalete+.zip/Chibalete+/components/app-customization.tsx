"use client"

import { useState, useEffect } from "react"
import { useStore } from "@/lib/store"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { AppSettings } from "@prisma/client"

export function AppCustomization() {
  const { appSettings, setAppSettings } = useStore()
  const [theme, setTheme] = useState(appSettings?.theme || "light")
  const [primaryColor, setPrimaryColor] = useState(appSettings?.primaryColor || "#000000")
  const [font, setFont] = useState(appSettings?.font || "sans")
  const [backgroundImage, setBackgroundImage] = useState<File | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetchAppSettings()
  }, [])

  const fetchAppSettings = async () => {
    try {
      const response = await fetch("/api/app-settings")
      if (!response.ok) throw new Error("Failed to fetch app settings")
      const data = await response.json()
      setAppSettings(data)
      setTheme(data.theme)
      setPrimaryColor(data.primaryColor)
      setFont(data.font)
    } catch (err) {
      setError("Failed to load app settings")
    }
  }

  const saveSettings = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    const formData = new FormData()
    formData.append("theme", theme)
    formData.append("primaryColor", primaryColor)
    formData.append("font", font)
    if (backgroundImage) {
      formData.append("backgroundImage", backgroundImage)
    }

    try {
      const response = await fetch("/api/app-settings", {
        method: "PUT",
        body: formData,
      })
      if (!response.ok) throw new Error("Failed to update app settings")
      const updatedSettings = await response.json()
      setAppSettings(updatedSettings)
    } catch (err) {
      setError("Failed to save app settings")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">App Customization</h2>
        <p className="text-gray-600">Customize the look and feel of the Chibalete+ app</p>
      </div>
      <form onSubmit={saveSettings} className="space-y-4">
        <div>
          <Label htmlFor="theme">App Theme</Label>
          <Select value={theme} onValueChange={setTheme}>
            <SelectTrigger id="theme">
              <SelectValue placeholder="Select a theme" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="light">Light</SelectItem>
              <SelectItem value="dark">Dark</SelectItem>
              <SelectItem value="system">System</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="primary-color">Primary Color</Label>
          <Input id="primary-color" type="color" value={primaryColor} onChange={(e) => setPrimaryColor(e.target.value)} className="h-10 w-20" />
        </div>
        <div>
          <Label htmlFor="font">Font</Label>
          <Select value={font} onValueChange={setFont}>
            <SelectTrigger id="font">
              <SelectValue placeholder="Select a font" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="sans">Sans-serif</SelectItem>
              <SelectItem value="serif">Serif</SelectItem>
              <SelectItem value="mono">Monospace</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="background-image">Login Background Image</Label>
          <Input id="background-image" type="file" accept="image/*" onChange={(e) => setBackgroundImage(e.target.files?.[0] || null)} />
        </div>
        <Button type="submit" disabled={loading}>
          {loading ? "Saving..." : "Save Customization"}
        </Button>
      </form>
      {error && <div className="text-red-500">{error}</div>}
    </div>
  )
}

