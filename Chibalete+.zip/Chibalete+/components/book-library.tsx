import Link from "next/link"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

const books = [
  { id: 1, title: "The Great Gatsby", author: "F. Scott Fitzgerald", cover: "/placeholder.svg" },
  { id: 2, title: "To Kill a Mockingbird", author: "Harper Lee", cover: "/placeholder.svg" },
  { id: 3, title: "1984", author: "George Orwell", cover: "/placeholder.svg" },
  { id: 4, title: "Pride and Prejudice", author: "Jane Austen", cover: "/placeholder.svg" },
  { id: 5, title: "The Catcher in the Rye", author: "J.D. Salinger", cover: "/placeholder.svg" },
  { id: 6, title: "Moby-Dick", author: "Herman Melville", cover: "/placeholder.svg" },
]

export function BookLibrary() {
  return (
    <div className="container mx-auto p-6">
      <h1 className="mb-6 text-3xl font-bold">Your Digital Library</h1>
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {books.map((book) => (
          <Card key={book.id} className="overflow-hidden">
            <CardHeader className="p-0">
              <img src={book.cover} alt={`Cover of ${book.title}`} className="h-48 w-full object-cover" />
            </CardHeader>
            <CardContent className="p-4">
              <CardTitle>{book.title}</CardTitle>
              <p className="text-sm text-gray-600">{book.author}</p>
            </
</ReactProject>

CardContent>
            <CardFooter>
              <Link href={`/book/${book.id}`} passHref>
                <Button className="w-full" aria-label={`Read ${book.title}`}>Read Now</Button>
              </Link>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}

